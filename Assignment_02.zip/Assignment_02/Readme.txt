
Steps to execute programs


1.
//change  to appropriate question directory (Q1 , Q2a ,Q2b , Q3a , Q3b , Q3c , Q3d)
cd Q1a
2.
#set Gl version to 3.3
export MESA_GL_VERSION_OVERRIDE=3.3

3.
//compile the program
./compile.h

4.
//run the program 
./sample.h


Additional Instruction :

 1. For Q1b
press 1 to rotate

2. For Q2a,Q2b,Q3a ,Q3b ,Q3b
press 1,2,3 to rotate around axes x,y,z  

